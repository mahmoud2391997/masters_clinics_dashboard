import React from 'react';
declare const MedicalDevicesPage: React.FC;
export default MedicalDevicesPage;
